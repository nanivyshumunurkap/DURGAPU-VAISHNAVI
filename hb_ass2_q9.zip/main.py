def calculate_power(base, exponent):
    result = 1 
    
    if exponent <0:
        base = 1/base
        exponent = _exponent
        
    while exponent>0:
        result *= base
        exponent -= 1 
        
    return result
    
base = float(input("enter the base:"))
exponent = int(input("enter the exponent:"))

power_result = calculate_power(base,exponent)
print(f"{base} raised to the power of {exponent} is:{power_result})
