def find_greatest(num1,num2,num3):
    
    greatest = max(num1,num2,num3)
    return greatest
    
num1 = int(input("enter the first number:"))
num2 = int(input("enter the second number:"))
num3 = int(input("enter the third number:"))

result = find_greatest(num1,num2,num3)
print(f"the greatest number among {num1}, {num2}, {num3} is: {result}")