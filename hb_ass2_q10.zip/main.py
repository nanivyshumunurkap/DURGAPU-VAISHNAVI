def calculate_gcd(x,y):
    while y:
        x,y = y,x % y
        return x 
        
def calculate_lcm(x, y):
    # calculate_lcm = (x,y)/ calculate_gcd(x,y)
    return (x*y)//calculate_gcd(x,y)
    
number1 = int(input("enter the first number:"))
number2 = int(input("enter the second number:"))

lcm_result = calculate_lcm(number1,number2)
print(f"the lcm of {number1} and {number2} is:{lcm_result}")