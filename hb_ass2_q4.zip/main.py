input_str = 'I am 25 years and 15 months old'
result_str = '.join(char for char in input_str if char.isdigit())'


print("original string:", input_str)
print("string with only integers:",result_str