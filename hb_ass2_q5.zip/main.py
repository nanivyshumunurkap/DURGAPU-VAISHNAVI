import re

def find_alphanumeric_words(input_str):
    words = input_str.split()
    alphanumeric_words = [word for word in words if re.search(r'[a-zA-Z]+.*\d+.*[a-zA-Z]+',word)]
    return alphanumeric_words
    
input_str = 'rahul54 is data engineer13 and AI expert'
result = find_alphanumeric_words(input_str)


print("original string:",input_str)
print("words with both alphabets and numbers:",result)