def calculate_power(base, exponent):
    result = 1
    
    if exponent <0:
        base = 1 /base
        exponent = -exponent
        
        
    for_in range(exponent):
        result *= base
        
        return result
        
base  = float(input("enter the base:"))
exponent = int(input("enter the exponent:"))

power_result = calculate_power(base,exponent)
print(f"{base}raised to the power of {exponent} is:{power_result}")