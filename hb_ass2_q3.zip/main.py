list = ["rahul,"john","","karan",None,"vishal",""]
filtered_lst = [item for item in lst if item and item.strip()]
print(filtered_lst)