def swap_number_with_variable(num1,num2):
    temp = num1
    
    num1 = num2
    
    num2 = temp
    
    print("after swapping:")
    print("first number:", num1)
    print("second number:", num2)
    
num1 = float(input("enter the first number:"))
num2 = float(input("enter the second number:"))

print("before swapping:")
print("first number:", number1)
print("second number:",number2)

swap_number_with_variable(number1, number1)
